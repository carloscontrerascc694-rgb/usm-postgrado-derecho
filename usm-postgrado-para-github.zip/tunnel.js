// ============================================================
// tunnel.js - Túnel público para acceso desde Internet
// Sistema de Preinscripción - Postgrado en Derecho USM
// ============================================================
//
// Genera dos enlaces públicos simultáneos:
// 1. Enlace con nombre fácil y oficial USM: https://usm-postgrado-derecho.loca.lt
// 2. Enlace de respaldo de alta velocidad Cloudflare: https://*.trycloudflare.com
//
// Uso: node tunnel.js
// ============================================================

require('dotenv').config();
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const express = require('express');
const localtunnel = require('localtunnel');
const { v4: uuidv4 } = require('uuid');

const PORT = process.env.PORT || 3000;
const SUBDOMINIO_FACIL = 'usm-postgrado-derecho';

const {
    inicializarDB,
    obtenerProgramas,
    obtenerProgramaPorId,
    crearPreinscripcion,
    obtenerPreinscripcionPorCodigo,
    obtenerTodasPreinscripciones,
    actualizarEstado,
    marcarCorreoEnviado,
    obtenerEstadisticas,
    existePreinscripcion
} = require('./database');

const {
    enviarCorreoConfirmacion,
    enviarNotificacionAdmin,
    generarHtmlCorreo,
    verificarCredencialesGmail
} = require('./email');

async function iniciarConTunel() {
    await inicializarDB();

    const app = express();

    function getNetworkIp() {
        const interfaces = os.networkInterfaces();
        for (const name of Object.keys(interfaces)) {
            for (const iface of interfaces[name]) {
                if (iface.family === 'IPv4' && !iface.internal) return iface.address;
            }
        }
        return 'localhost';
    }

    let urlFacil = `https://${SUBDOMINIO_FACIL}.loca.lt`;
    let urlCloudflare = null;
    let publicIp = '190.94.212.200';

    // Obtener IP pública real en segundo plano
    fetch('https://api.ipify.org').then(r => r.text()).then(ip => {
        if (ip && ip.trim()) publicIp = ip.trim();
    }).catch(() => {});

    function resolveBaseUrl(req) {
        if (req) {
            const host = req.get('host');
            if (host) return `${req.protocol}://${host}`;
        }
        if (urlCloudflare) return urlCloudflare;
        if (urlFacil) return urlFacil;
        const ip = getNetworkIp();
        return `http://${ip}:${PORT}`;
    }

    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.use(express.static(path.join(__dirname, 'public')));

    // Rutas API
    app.get('/api/programas', (req, res) => {
        try {
            const programas = obtenerProgramas();
            res.json({ success: true, data: programas });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al obtener programas' });
        }
    });

    app.post('/api/preinscripcion', async (req, res) => {
        try {
            const {
                cedula, nombres, apellidos, fecha_nacimiento, genero,
                email, telefono, direccion, ciudad, estado,
                universidad_egreso, titulo_obtenido, anio_egreso,
                programa_id, motivacion
            } = req.body;

            if (!cedula || !nombres || !apellidos || !email || !telefono || !programa_id) {
                return res.status(400).json({ success: false, message: 'Complete todos los campos obligatorios.' });
            }

            if (fecha_nacimiento) {
                const birthDate = new Date(fecha_nacimiento);
                if (isNaN(birthDate.getTime())) {
                    return res.status(400).json({ success: false, message: 'La fecha de nacimiento no tiene un formato válido.' });
                }
                const today = new Date();
                let age = today.getFullYear() - birthDate.getFullYear();
                const m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) age--;
                if (age < 20 || age > 95) {
                    return res.status(400).json({ success: false, message: 'Debe ingresar una fecha de nacimiento válida (edad entre 20 y 95 años para estudios de postgrado).' });
                }
            }

            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                return res.status(400).json({ success: false, message: 'El formato del correo electrónico no es válido.' });
            }

            const progId = parseInt(programa_id, 10);
            if (isNaN(progId)) {
                return res.status(400).json({ success: false, message: 'El programa seleccionado no es válido.' });
            }

            const programa = obtenerProgramaPorId(progId);
            if (!programa) {
                return res.status(400).json({ success: false, message: 'El programa seleccionado no existe.' });
            }

            if (existePreinscripcion(cedula.trim(), progId)) {
                return res.status(409).json({ success: false, message: 'Ya existe una preinscripción activa con esta cédula para el programa seleccionado.' });
            }

            const codigoSolicitud = 'USM-DER-' + Date.now().toString(36).toUpperCase() + '-' + uuidv4().substring(0, 6).toUpperCase();

            const datos = {
                codigo_solicitud: codigoSolicitud,
                cedula: cedula.trim(),
                nombres: nombres.trim(),
                apellidos: apellidos.trim(),
                fecha_nacimiento: fecha_nacimiento || null,
                genero: genero || null,
                email: email.trim().toLowerCase(),
                telefono: telefono.trim(),
                direccion: direccion ? direccion.trim() : null,
                ciudad: ciudad ? ciudad.trim() : null,
                estado: estado ? estado.trim() : null,
                universidad_egreso: universidad_egreso ? universidad_egreso.trim() : null,
                titulo_obtenido: titulo_obtenido ? titulo_obtenido.trim() : null,
                anio_egreso: anio_egreso && !isNaN(parseInt(anio_egreso, 10)) ? parseInt(anio_egreso, 10) : null,
                programa_id: progId,
                motivacion: motivacion ? motivacion.trim() : null
            };

            crearPreinscripcion(datos);
            const preinscripcionCompleta = obtenerPreinscripcionPorCodigo(codigoSolicitud);
            const baseUrl = resolveBaseUrl(req);
            const resultadoCorreo = await enviarCorreoConfirmacion(preinscripcionCompleta, baseUrl);

            if (resultadoCorreo.success) marcarCorreoEnviado(codigoSolicitud);
            enviarNotificacionAdmin(preinscripcionCompleta).catch(() => {});

            res.status(201).json({
                success: true,
                message: 'Preinscripción registrada exitosamente. Se ha generado la información y los requisitos del postgrado.',
                data: {
                    codigo_solicitud: codigoSolicitud,
                    programa: programa.nombre,
                    correo_enviado: resultadoCorreo.success,
                    link_consulta: `${baseUrl}/consulta.html?codigo=${codigoSolicitud}`,
                    link_correo: `${baseUrl}/api/preinscripcion/${codigoSolicitud}/correo`,
                    preview_correo_url: resultadoCorreo.previewUrl || null
                }
            });
        } catch (error) {
            console.error('Error creando preinscripción:', error);
            res.status(500).json({ success: false, message: 'Error interno al procesar la preinscripción.' });
        }
    });

    app.get('/api/preinscripcion/:codigo', (req, res) => {
        try {
            const preinscripcion = obtenerPreinscripcionPorCodigo(req.params.codigo);
            if (!preinscripcion) return res.status(404).json({ success: false, message: 'No se encontró ninguna preinscripción con ese código.' });
            res.json({ success: true, data: preinscripcion });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al consultar la preinscripción.' });
        }
    });

    app.get('/api/admin/preinscripciones', (req, res) => {
        try {
            const filtros = {
                estado: req.query.estado || null,
                programa_id: req.query.programa_id ? parseInt(req.query.programa_id) : null,
                busqueda: req.query.busqueda || null
            };
            const preinscripciones = obtenerTodasPreinscripciones(filtros);
            res.json({ success: true, data: preinscripciones });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al obtener preinscripciones.' });
        }
    });

    app.put('/api/admin/preinscripcion/:codigo/estado', (req, res) => {
        try {
            const { estado } = req.body;
            const estadosValidos = ['pendiente', 'revisada', 'aceptada', 'rechazada'];
            if (!estado || !estadosValidos.includes(estado)) {
                return res.status(400).json({ success: false, message: 'Estado no válido.' });
            }
            actualizarEstado(req.params.codigo, estado);
            res.json({ success: true, message: `Estado actualizado a "${estado}".` });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al actualizar estado.' });
        }
    });

    app.get('/api/admin/estadisticas', (req, res) => {
        try {
            const stats = obtenerEstadisticas();
            res.json({ success: true, data: stats });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al obtener estadísticas.' });
        }
    });

    app.get('/api/preinscripcion/:codigo/correo', (req, res) => {
        try {
            const preinscripcion = obtenerPreinscripcionPorCodigo(req.params.codigo);
            if (!preinscripcion) return res.status(404).send('<h2 style="font-family:sans-serif; text-align:center; margin-top:50px;">Solicitud no encontrada.</h2>');
            const baseUrl = resolveBaseUrl(req);
            const html = generarHtmlCorreo(preinscripcion, baseUrl);
            res.setHeader('Content-Type', 'text/html; charset=utf-8');
            res.send(html);
        } catch (error) {
            res.status(500).send('<h2>Error al generar la vista del correo.</h2>');
        }
    });

    app.get('/api/admin/estado-correo', (req, res) => {
        const user = process.env.SMTP_USER || 'carloscontrerascc694@gmail.com';
        const pass = process.env.SMTP_PASS || '';
        const activo = Boolean(pass && pass.trim().length >= 10);
        res.json({ success: true, data: { email: user, conectado: activo } });
    });

    app.post('/api/admin/activar-gmail', async (req, res) => {
        try {
            let { email, pass } = req.body;
            if (!email || !pass) return res.status(400).json({ success: false, message: 'Debe ingresar su correo de Gmail y la clave de aplicación.' });
            email = email.trim().toLowerCase();
            const cleanPass = pass.replace(/\s+/g, '');
            if (cleanPass.length < 12) return res.status(400).json({ success: false, message: 'La clave de aplicación de Google debe tener 16 letras.' });

            try { await verificarCredencialesGmail(email, cleanPass); } catch (authError) {
                return res.status(400).json({ success: false, message: `Google no aceptó la clave: ${authError.message}.` });
            }

            process.env.SMTP_USER = email;
            process.env.SMTP_PASS = cleanPass;
            process.env.ADMIN_EMAIL = email;

            const envContent = `# Puerto del servidor web\nPORT=${process.env.PORT || 3000}\n\n# URL base del sistema\nBASE_URL=${process.env.BASE_URL || 'http://192.168.10.12:3000'}\n\n# Correo remitente y coordinador oficial\nADMIN_EMAIL=${email}\nSMTP_USER=${email}\nSMTP_PASS=${cleanPass}\n`;
            fs.writeFileSync(path.join(__dirname, '.env'), envContent);

            res.json({ success: true, message: `¡Gmail conectado con éxito! Ahora los aspirantes recibirán su correo directamente.` });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al activar Gmail: ' + error.message });
        }
    });

    app.post('/api/admin/preinscripcion/:codigo/reenviar-correo', async (req, res) => {
        try {
            const preinscripcion = obtenerPreinscripcionPorCodigo(req.params.codigo);
            if (!preinscripcion) return res.status(404).json({ success: false, message: 'No encontrada.' });
            const baseUrl = resolveBaseUrl(req);
            const resultado = await enviarCorreoConfirmacion(preinscripcion, baseUrl);
            if (resultado.success) {
                marcarCorreoEnviado(req.params.codigo);
                return res.json({ success: true, message: `✅ Correo enviado a ${preinscripcion.email} ${resultado.realDelivery ? '(directo en Gmail)' : ''}`, data: resultado });
            }
            return res.status(500).json({ success: false, message: `Error: ${resultado.error || 'Desconocido'}` });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error interno al reenviar correo.' });
        }
    });

    app.post('/api/admin/probar-correo', async (req, res) => {
        try {
            const { destino } = req.body;
            if (!destino || !destino.includes('@')) return res.status(400).json({ success: false, message: 'Indique un correo válido.' });
            const preinscripcionEjemplo = {
                codigo_solicitud: 'USM-PRUEBA-' + Math.floor(1000 + Math.random() * 9000),
                nombres: 'Aspirante de', apellidos: 'Prueba', cedula: 'V-00.000.000',
                email: destino.trim().toLowerCase(), telefono: '0412-0000000',
                universidad_egreso: 'Universidad Santa María', titulo_obtenido: 'Abogado',
                programa_nombre: 'Especialización en Derecho Penal', programa_tipo: 'Especialización',
                programa_duracion: '2 semestres', programa_modalidad: 'Presencial'
            };
            const baseUrl = resolveBaseUrl(req);
            const resultado = await enviarCorreoConfirmacion(preinscripcionEjemplo, baseUrl);
            if (resultado.success) return res.json({ success: true, message: `✅ Correo enviado a ${destino}.`, data: resultado });
            return res.status(500).json({ success: false, message: `Error: ${resultado.error || 'Fallo'}` });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error: ' + error.message });
        }
    });

    app.get('/api/info-red', (req, res) => {
        try {
            const ip = getNetworkIp();
            const urlLocal = `http://localhost:${PORT}`;
            const urlRed = `http://${ip}:${PORT}`;
            const urlAdmin = `http://${ip}:${PORT}/admin.html`;
            const qrBase = urlCloudflare || urlFacil || urlRed;
            const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&margin=10&data=${encodeURIComponent(qrBase)}`;
            res.json({
                success: true,
                data: {
                    ip,
                    puerto: PORT,
                    urlLocal,
                    urlRed,
                    urlAdmin,
                    qrUrl,
                    urlFacil,
                    urlCloudflare,
                    publicIp
                }
            });
        } catch (error) {
            res.status(500).json({ success: false, message: 'Error al obtener info de red.' });
        }
    });

    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, 'public', 'index.html'));
    });

    // 1. Iniciar servidor local
    await new Promise((resolve) => {
        app.listen(PORT, '0.0.0.0', () => {
            console.log('');
            console.log('  ✅ Servidor local activo en http://localhost:' + PORT);
            resolve();
        });
    });

    // 2. Iniciar Túnel Localtunnel con reconexión automática (Enlace con nombre fácil)
    async function conectarLocaltunnel() {
        try {
            const tunnel = await localtunnel({ port: parseInt(PORT, 10), subdomain: SUBDOMINIO_FACIL });
            urlFacil = tunnel.url;

            tunnel.on('close', () => {
                setTimeout(conectarLocaltunnel, 2000);
            });

            tunnel.on('error', () => {
                try { tunnel.close(); } catch(e) {}
            });
        } catch (err) {
            setTimeout(conectarLocaltunnel, 3000);
        }
    }
    conectarLocaltunnel();

    // 3. Iniciar Túnel Cloudflare (Enlace de respaldo ultra rápido sin pantallas)
    const cloudflaredExe = path.join(__dirname, 'cloudflared.exe');
    if (fs.existsSync(cloudflaredExe)) {
        const cf = spawn(cloudflaredExe, ['tunnel', '--url', `http://localhost:${PORT}`], {
            windowsHide: true
        });

        cf.stderr.on('data', (data) => {
            const text = data.toString();
            const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
            if (match && !urlCloudflare) {
                urlCloudflare = match[0];
                guardarYMostrarBanner(urlFacil, urlCloudflare, getNetworkIp(), publicIp);
            }
        });

        process.on('exit', () => {
            try { cf.kill(); } catch (e) {}
        });
    } else {
        guardarYMostrarBanner(urlFacil, null, getNetworkIp(), publicIp);
    }
}

function guardarYMostrarBanner(urlFacil, urlCloudflare, localIp, publicIp) {
    const contenidoTxt = `===========================================================
ENLACES DE ACCESO - POSTGRADO EN DERECHO USM
===========================================================

1. ENLACE OFICIAL USM (Nombre facil para compartir):
   ${urlFacil}
   (Si te pide "Tunnel Password", coloca: ${publicIp})

2. ENLACE DIRECTO CLOUDFLARE (Ultra rapido, sin clave):
   ${urlCloudflare || 'Iniciando...'}

3. EN LA RED WI-FI (Mismo internet):
   http://${localIp}:${PORT}

4. EN ESTA COMPUTADORA:
   http://localhost:${PORT}
`;
    fs.writeFileSync(path.join(__dirname, 'ENLACE_PUBLICO.txt'), contenidoTxt);

    console.log('');
    console.log('  ╔══════════════════════════════════════════════════════════════════════════╗');
    console.log('  ║                                                                          ║');
    console.log('  ║   🎓  UNIVERSIDAD SANTA MARÍA - POSTGRADO EN DERECHO                     ║');
    console.log('  ║   🌍  ¡ACCESO PÚBLICO ACTIVADO CON NOMBRE OFICIAL!                       ║');
    console.log('  ║                                                                          ║');
    console.log('  ╠══════════════════════════════════════════════════════════════════════════╣');
    console.log('  ║                                                                          ║');
    console.log('  ║   ⭐ ENLACE FÁCIL OFICIAL (Con nombre referente al sistema):             ║');
    console.log(`  ║      ${urlFacil.padEnd(64)}║`);
    console.log('  ║                                                                          ║');
    console.log('  ║   ⚡ ENLACE DIRECTO ALTERNATIVO (Sin contraseña / Cloudflare):            ║');
    console.log(`  ║      ${(urlCloudflare || 'Iniciando...').padEnd(64)}║`);
    console.log('  ║                                                                          ║');
    console.log('  ║   📱 En la misma red Wi-Fi:                                              ║');
    console.log(`  ║      http://${localIp}:${PORT}`.padEnd(71) + '║');
    console.log('  ║                                                                          ║');
    console.log('  ╚══════════════════════════════════════════════════════════════════════════╝');
    console.log('');
    console.log(`  👉 Puedes enviar este enlace oficial por WhatsApp:`);
    console.log(`     🔗 ${urlFacil}`);
    console.log(`     (Si pide Tunnel Password en la primera visita, escribe: ${publicIp})`);
    console.log('');
    console.log(`  👉 O si quieres que abra directo sin pedir nada:`);
    console.log(`     🔗 ${urlCloudflare}`);
    console.log('');
    console.log('  📁 Se guardaron ambos en: ENLACE_PUBLICO.txt');
    console.log('');
}

iniciarConTunel().catch(err => {
    console.error('❌ Error al iniciar:', err);
    process.exit(1);
});
