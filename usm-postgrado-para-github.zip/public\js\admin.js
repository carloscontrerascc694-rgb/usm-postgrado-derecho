// ============================================================
// admin.js - Lógica del panel de administración
// Sistema de Preinscripción - Postgrado en Derecho USM
// ============================================================

// ============================================================
// Inicialización
// ============================================================
document.addEventListener('DOMContentLoaded', () => {
    cargarEstadisticas();
    cargarProgramasFiltro();
    cargarPreinscripciones();
    verificarEstadoGmail();
    cargarInfoRed();

    // Filtrar al escribir (con debounce)
    let debounce;
    document.getElementById('filtBusqueda').addEventListener('input', () => {
        clearTimeout(debounce);
        debounce = setTimeout(cargarPreinscripciones, 400);
    });

    document.getElementById('filtEstado').addEventListener('change', cargarPreinscripciones);
    document.getElementById('filtPrograma').addEventListener('change', cargarPreinscripciones);
});

// ============================================================
// Cargar estadísticas
// ============================================================
async function cargarEstadisticas() {
    try {
        const response = await fetch('/api/admin/estadisticas');
        const data = await response.json();

        if (data.success) {
            const stats = data.data;
            document.getElementById('statTotal').textContent = stats.total;

            const porEstado = {};
            stats.porEstado.forEach(e => porEstado[e.estado_solicitud] = e.total);

            document.getElementById('statPendientes').textContent = (porEstado.pendiente || 0) + (porEstado.revisada || 0);
            document.getElementById('statAceptadas').textContent = porEstado.aceptada || 0;
            document.getElementById('statRechazadas').textContent = porEstado.rechazada || 0;
        }
    } catch (error) {
        console.error('Error cargando estadísticas:', error);
    }
}

// ============================================================
// Cargar programas en el filtro
// ============================================================
async function cargarProgramasFiltro() {
    try {
        const response = await fetch('/api/programas');
        const data = await response.json();

        if (data.success) {
            const select = document.getElementById('filtPrograma');
            data.data.forEach(p => {
                const option = document.createElement('option');
                option.value = p.id;
                option.textContent = p.nombre;
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error cargando programas:', error);
    }
}

// ============================================================
// Cargar preinscripciones
// ============================================================
async function cargarPreinscripciones() {
    const params = new URLSearchParams();
    const busqueda = document.getElementById('filtBusqueda').value.trim();
    const estado = document.getElementById('filtEstado').value;
    const programa = document.getElementById('filtPrograma').value;

    if (busqueda) params.set('busqueda', busqueda);
    if (estado) params.set('estado', estado);
    if (programa) params.set('programa_id', programa);

    try {
        const response = await fetch(`/api/admin/preinscripciones?${params.toString()}`);
        const data = await response.json();

        if (data.success) {
            renderizarTabla(data.data);
        }
    } catch (error) {
        console.error('Error cargando preinscripciones:', error);
    }
}

// ============================================================
// Helpers seguros
// ============================================================
function escapeHtml(text) {
    if (text === null || text === undefined) return '';
    return String(text)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function formatearFecha(fechaStr) {
    if (!fechaStr) return 'N/A';
    try {
        const d = new Date(String(fechaStr).replace(' ', 'T'));
        if (isNaN(d.getTime())) return String(fechaStr);
        return d.toLocaleDateString('es-VE', {
            day: '2-digit', month: '2-digit', year: 'numeric'
        });
    } catch (e) {
        return String(fechaStr);
    }
}

// ============================================================
// Renderizar tabla
// ============================================================
function renderizarTabla(preinscripciones) {
    const tbody = document.getElementById('tablaBody');

    if (!Array.isArray(preinscripciones) || preinscripciones.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="text-center text-muted" style="padding: 30px;">
                    No se encontraron preinscripciones.
                </td>
            </tr>
        `;
        return;
    }

    const estadoColores = {
        pendiente: { bg: '#fff3e0', color: '#e65100', text: '⏳ Pendiente' },
        revisada: { bg: '#e3f2fd', color: '#1565c0', text: '👁️ Revisada' },
        aceptada: { bg: '#e8f5e9', color: '#2e7d32', text: '✅ Aceptada' },
        rechazada: { bg: '#ffebee', color: '#c62828', text: '❌ Rechazada' }
    };

    tbody.innerHTML = preinscripciones.map(p => {
        const est = estadoColores[p.estado_solicitud] || estadoColores.pendiente;
        const fecha = formatearFecha(p.fecha_registro);

        return `
            <tr>
                <td><code style="font-size: 11px; color: #1a237e;">${escapeHtml(p.codigo_solicitud)}</code></td>
                <td><strong>${escapeHtml(p.nombres)} ${escapeHtml(p.apellidos)}</strong></td>
                <td>${escapeHtml(p.cedula)}</td>
                <td><a href="mailto:${encodeURIComponent(p.email)}" style="color: #1565c0;">${escapeHtml(p.email)}</a></td>
                <td style="font-size: 12px;">${escapeHtml(p.programa_nombre)}</td>
                <td style="white-space: nowrap;">${fecha}</td>
                <td>
                    <span class="badge-estado" style="background: ${est.bg}; color: ${est.color};">
                        ${est.text}
                    </span>
                </td>
                <td style="white-space: nowrap;">
                    <div style="display: flex; gap: 6px; align-items: center;">
                        <button type="button" onclick="reenviarCorreoAspirante('${escapeHtml(p.codigo_solicitud)}', '${escapeHtml(p.email)}', this)"
                                class="btn btn-sm btn-primary" style="padding: 4px 9px; font-size: 11px; font-weight: 700; background: #1a237e; border: none; white-space: nowrap;"
                                title="Enviar o reenviar requisitos directamente a la bandeja de Gmail del aspirante">
                            ✉️ Reenviar a Gmail
                        </button>
                        <a href="/api/preinscripcion/${encodeURIComponent(p.codigo_solicitud)}/correo" target="_blank" 
                           class="btn btn-sm btn-outline" style="padding: 3px 8px; font-size: 11px; text-decoration: none;" title="Ver correo en línea">
                            📄 Ver
                        </a>
                        <select onchange="cambiarEstado('${escapeHtml(p.codigo_solicitud)}', this.value, this)" 
                                style="padding: 4px 6px; font-size: 12px; border: 1px solid #ddd; border-radius: 4px;">
                            <option value="">Estado...</option>
                            <option value="pendiente" ${p.estado_solicitud === 'pendiente' ? 'disabled' : ''}>⏳ Pendiente</option>
                            <option value="revisada" ${p.estado_solicitud === 'revisada' ? 'disabled' : ''}>👁️ Revisada</option>
                            <option value="aceptada" ${p.estado_solicitud === 'aceptada' ? 'disabled' : ''}>✅ Aceptar</option>
                            <option value="rechazada" ${p.estado_solicitud === 'rechazada' ? 'disabled' : ''}>❌ Rechazar</option>
                        </select>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// ============================================================
// Cambiar estado de una preinscripción
// ============================================================
async function cambiarEstado(codigo, nuevoEstado, selectEl) {
    if (!nuevoEstado) return;

    const confirmMsg = nuevoEstado === 'aceptada'
        ? '¿Confirma que desea ACEPTAR esta preinscripción?'
        : nuevoEstado === 'rechazada'
            ? '¿Confirma que desea RECHAZAR esta preinscripción?'
            : `¿Cambiar el estado a "${nuevoEstado}"?`;

    if (!confirm(confirmMsg)) {
        if (selectEl) selectEl.value = '';
        return;
    }

    try {
        const response = await fetch(`/api/admin/preinscripcion/${encodeURIComponent(codigo)}/estado`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ estado: nuevoEstado })
        });

        const data = await response.json();

        if (data.success) {
            cargarPreinscripciones();
            cargarEstadisticas();
        } else {
            alert('Error: ' + data.message);
        }
    } catch (error) {
        alert('Error de conexión al actualizar el estado.');
    }
}

// ============================================================
// Activación y Estado de Gmail Real
// ============================================================

async function verificarEstadoGmail() {
    try {
        const response = await fetch('/api/admin/estado-correo');
        const data = await response.json();

        if (data.success) {
            const badge = document.getElementById('badgeEstadoGmail');
            const userInput = document.getElementById('inputGmailUser');
            if (userInput && data.data.email) {
                userInput.value = data.data.email;
            }

            if (data.data.conectado) {
                badge.textContent = '🟢 Envío Real Activo';
                badge.style.background = '#e8f5e9';
                badge.style.color = '#2e7d32';
            } else {
                badge.textContent = '🟡 Pendiente Clave';
                badge.style.background = '#fff3e0';
                badge.style.color = '#e65100';
            }
        }
    } catch (e) {
        console.error('Error consultando estado de correo:', e);
    }
}

async function activarGmailReal(e) {
    e.preventDefault();

    const btn = document.getElementById('btnActivarGmail');
    const alerta = document.getElementById('alertaGmail');
    const email = document.getElementById('inputGmailUser').value.trim();
    const pass = document.getElementById('inputGmailPass').value.trim();

    btn.disabled = true;
    btn.innerHTML = '⏳ Verificando con Google...';
    alerta.innerHTML = '';

    try {
        const response = await fetch('/api/admin/activar-gmail', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, pass })
        });

        const data = await response.json();

        if (data.success) {
            alerta.innerHTML = `
                <div class="alert alert-success" style="margin-bottom: 15px;">
                    <span>✅</span>
                    <div>
                        <strong>¡Conexión Exitosa con Gmail!</strong>
                        <p>${data.message}</p>
                    </div>
                </div>
            `;
            document.getElementById('inputGmailPass').value = '';
            verificarEstadoGmail();
        } else {
            alerta.innerHTML = `
                <div class="alert alert-error" style="margin-bottom: 15px;">
                    <span>❌</span>
                    <div>
                        <strong>No se pudo conectar:</strong>
                        <p>${data.message}</p>
                    </div>
                </div>
            `;
        }
    } catch (err) {
        alerta.innerHTML = `
            <div class="alert alert-error" style="margin-bottom: 15px;">
                <span>❌</span>
                <div>
                    <strong>Error de conexión:</strong>
                    <p>No se pudo comunicar con el servidor local.</p>
                </div>
            </div>
        `;
    } finally {
        btn.disabled = false;
        btn.innerHTML = '🚀 Conectar y Activar Envío Real';
    }
}

// ============================================================
// Reenviar correo con requisitos directamente al Gmail del aspirante
// ============================================================
async function reenviarCorreoAspirante(codigo, email, btn) {
    if (!confirm(`¿Desea reenviar el correo oficial con los requisitos y enlaces USM directamente al Gmail de ${email}?`)) {
        return;
    }

    const textoOriginal = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '⏳ Enviando...';

    try {
        const response = await fetch(`/api/admin/preinscripcion/${encodeURIComponent(codigo)}/reenviar-correo`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (data.success) {
            alert(`✅ ${data.message}`);
            cargarPreinscripciones();
        } else {
            alert(`❌ Error al enviar: ${data.message}`);
        }
    } catch (err) {
        alert('❌ Error de comunicación con el servidor.');
    } finally {
        btn.disabled = false;
        btn.innerHTML = textoOriginal;
    }
}

// ============================================================
// Enviar correo de prueba a cualquier dirección
// ============================================================
async function probarEnvioGmail(e) {
    e.preventDefault();

    const input = document.getElementById('inputDestinoPrueba');
    const btn = document.getElementById('btnProbarEnvio');
    const alerta = document.getElementById('alertaPrueba');
    const destino = input.value.trim();

    if (!destino) return;

    btn.disabled = true;
    btn.innerHTML = '⏳ Enviando prueba...';
    alerta.innerHTML = '';

    try {
        const response = await fetch('/api/admin/probar-correo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ destino })
        });

        const data = await response.json();

        if (data.success) {
            alerta.innerHTML = `
                <div class="alert alert-success" style="margin-top: 10px; font-size: 13px;">
                    <span>✅</span>
                    <div>
                        <strong>${data.message}</strong>
                        <p style="margin: 4px 0 0; font-size: 12px;">Por favor abre tu Gmail (${destino}) en la bandeja principal o en Spam para verificarlo.</p>
                    </div>
                </div>
            `;
        } else {
            alerta.innerHTML = `
                <div class="alert alert-error" style="margin-top: 10px; font-size: 13px;">
                    <span>❌</span>
                    <div>
                        <strong>Error al enviar:</strong>
                        <p style="margin: 4px 0 0;">${data.message}</p>
                    </div>
                </div>
            `;
        }
    } catch (err) {
        alerta.innerHTML = `
            <div class="alert alert-error" style="margin-top: 10px; font-size: 13px;">
                <span>❌</span>
                <div><strong>Error:</strong> No se pudo conectar con el servidor.</div>
            </div>
        `;
    } finally {
        btn.disabled = false;
        btn.innerHTML = '✉️ Enviar Correo de Prueba';
    }
}

// ============================================================
// Cargar información de red local y QR para teléfonos
// ============================================================
async function cargarInfoRed() {
    try {
        const response = await fetch('/api/info-red');
        const data = await response.json();

        if (data.success && data.data) {
            const input = document.getElementById('inputUrlRed');
            const btnAbrir = document.getElementById('btnAbrirUrlRed');
            const imgQr = document.getElementById('imgQrRed');

            if (input) input.value = data.data.urlRed;
            if (btnAbrir) btnAbrir.href = data.data.urlRed;
            if (imgQr && data.data.qrUrl) imgQr.src = data.data.qrUrl;
        }
    } catch (e) {
        console.warn('No se pudo cargar info de red dinámica:', e);
    }
}

function copiarUrlRed() {
    const input = document.getElementById('inputUrlRed');
    if (!input) return;

    input.select();
    input.setSelectionRange(0, 99999); // Para móviles

    navigator.clipboard.writeText(input.value)
        .then(() => alert('📋 ¡Enlace copiado al portapapeles! Envíalo por WhatsApp o escríbelo en el navegador de tu celular.'))
        .catch(() => alert('Enlace: ' + input.value));
}



