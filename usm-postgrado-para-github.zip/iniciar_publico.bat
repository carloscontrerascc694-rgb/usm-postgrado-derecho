@echo off
title USM Postgrado - ACCESO PUBLICO DESDE INTERNET
cd /d "%~dp0"

echo ============================================================
echo   UNIVERSIDAD SANTA MARIA - FACULTAD DE DERECHO
echo   Sistema de Preinscripcion de Postgrado
echo.
echo   MODO: ACCESO PUBLICO DESDE INTERNET (CLOUDFLARE)
echo   Cualquier persona podra entrar desde cualquier lugar
echo ============================================================
echo.
echo [1/3] Liberando puerto 3000 de sesiones anteriores...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do taskkill /f /pid %%a >nul 2>&1
taskkill /f /im cloudflared.exe >nul 2>&1

echo [2/3] Iniciando servidor y abriendo tunel seguro...
echo (Espera unos segundos a que aparezca tu enlace publico)
echo.

node tunnel.js

echo.
echo ============================================================
echo El servidor se ha detenido.
echo ============================================================
pause

