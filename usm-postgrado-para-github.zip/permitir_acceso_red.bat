@echo off
title Permitir Acceso en Red Local - Sistema USM
echo ============================================================
echo   CONFIGURACION DE FIREWALL PARA ACCESO DESDE TELEFONOS
echo ============================================================
echo.
echo Agregando regla al Firewall de Windows para permitir el puerto 3000...
netsh advfirewall firewall add rule name="USM Postgrado Node Port 3000" dir=in action=allow protocol=TCP localport=3000
echo.
if %ERRORLEVEL% EQU 0 (
    echo [EXITO] Puerto 3000 habilitado correctamente en tu red.
    echo Ahora cualquier telefono o computadora en tu Wi-Fi puede entrar a:
    echo http://192.168.10.12:3000
) else (
    echo [AVISO] Si dio error de permisos, haz clic DERECHO en este archivo
    echo y selecciona "Ejecutar como administrador".
)
echo.
pause

