@echo off
title Sistema de Preinscripcion USM - Postgrado en Derecho
cd /d "%~dp0"

echo ============================================================
echo   UNIVERSIDAD SANTA MARIA - FACULTAD DE DERECHO
echo   Sistema de Preinscripcion de Postgrado
echo ============================================================
echo.
echo  Tienes 2 modos de acceso:
echo.
echo  [1] SOLO RED LOCAL (mismo Wi-Fi):
echo      Ejecuta este archivo: iniciar_sistema.bat
echo.
echo  [2] ACCESO PUBLICO DESDE INTERNET (cualquier lugar del mundo):
echo      Ejecuta este archivo: iniciar_publico.bat
echo.
echo ============================================================
echo.
echo Liberando puerto 3000 de sesiones anteriores...
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000 ^| findstr LISTENING') do taskkill /f /pid %%a >nul 2>&1
taskkill /f /im cloudflared.exe >nul 2>&1

echo Iniciando en modo RED LOCAL...
echo.
echo [1/2] Abriendo el sistema en tu navegador de esta computadora...
start "" http://localhost:3000
echo.
echo [2/2] Para ver la pagina desde tu TELEFONO (mismo Wi-Fi):
echo       Abre en tu celular: http://192.168.10.12:3000
echo.
echo Servidor en ejecucion (presiona Ctrl+C para detener)...
echo.
node server.js
pause
